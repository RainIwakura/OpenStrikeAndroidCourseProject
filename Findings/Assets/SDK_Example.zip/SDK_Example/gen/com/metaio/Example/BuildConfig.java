/** Automatically generated file. DO NOT MODIFY */
package com.metaio.Example;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}